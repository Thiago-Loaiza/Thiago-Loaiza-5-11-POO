﻿using System;

public class HelloWorld
{
    public static void Main(string[] args)
    {
        //3. Se ingresan por teclado tres números, si todos los valores ingresados son menores a 10, imprimir en pantalla
        //la leyenda "Todos los números son menores a diez"


        int n1, n2, n3;
        string linea;

        Console.Write("ingresa el primer numero: ");
        linea = Console.ReadLine();
        n1 = int.Parse(linea);

        Console.Write("ingresa el segundo numero: ");
        linea = Console.ReadLine();
        n2 = int.Parse(linea);

        Console.Write("ingresa el tercer numero: ");
        linea = Console.ReadLine();
        n3 = int.Parse(linea);

        if (n1 < 10 && n2 < 10 && n3 < 10)
        {
            Console.Write("Todos los números son menores a diez");
        }
        Console.ReadKey();
    }
}