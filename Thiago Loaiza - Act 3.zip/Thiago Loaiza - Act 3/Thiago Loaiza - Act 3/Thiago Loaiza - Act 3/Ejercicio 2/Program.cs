﻿using System;

public class HelloWorld
{
    public static void Main(string[] args)
    {
        //2.Se ingresan tres valores por teclado, si todos son iguales se imprime la suma del primero con el segundo y a este resultado
        //se lo multiplica por el tercero.

        int n1, n2, n3, total,suma;
        string linea;

        Console.Write("Numeros iguales");
        Console.Write("Ingresa el primer numero");
        linea = Console.ReadLine();
        n1 = int.Parse(linea);

        Console.Write("Ingresa el segundo numero");
        linea = Console.ReadLine();
        n2 = int.Parse(linea);

        Console.Write("Ingresa el tercer numero");
        linea = Console.ReadLine();
        n3 = int.Parse(linea);

        if (n1 == n2 && n2 == n3 && n1 == n3)
        {
            suma = n1 + n2;
            Console.Write("La suma de los 2 primeros es : " + suma);
            total = (n1 + n2) * n3;
            Console.Write("El total es : " + total);
        }
        else
        {
            Console.Write("Condicion rota");
        }
        Console.ReadKey();

    }
}
