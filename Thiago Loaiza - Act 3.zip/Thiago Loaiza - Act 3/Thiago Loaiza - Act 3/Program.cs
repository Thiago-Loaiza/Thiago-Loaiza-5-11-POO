﻿using System;

public class HelloWorld
{
    public static void Main(string[] args)
    {
        //1. Realizar un programa que pida cargar una fecha cualquiera, luego verificar si dicha fecha corresponde a Navidad.

        int dia, mes, año;
        string linea;

        Console.WriteLine("Ingresa con un formato de 2 digitos");
        Console.WriteLine("Ingresa el dia");
        linea = Console.ReadLine();
        dia = int.Parse(linea);

        Console.WriteLine("Ingresa el mes");
        linea = Console.ReadLine();
        mes = int.Parse(linea);

        Console.WriteLine("Ingresa el año");
        linea = Console.ReadLine();
        año = int.Parse(linea);

        if (dia == 25 && mes == 12)
        {
            Console.WriteLine("Feliz navida! jojo");
        }
        else
        {
            Console.WriteLine("No es navidad");
        }


        Console.ReadKey();
    }
}
