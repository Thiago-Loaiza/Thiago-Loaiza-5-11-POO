﻿using System;

public class HelloWorld
{
    public static void Main(string[] args)
    {
        //4. Se ingresan por teclado tres números, si al menos uno de los valores ingresados es menor a 10,
        //imprimir en pantalla la leyenda "Alguno de los números es menor a diez".

        int n1, n2, n3;
        string linea;

        Console.Write("Ingresa el primer numero: ");
        linea = Console.ReadLine();
        n1 = int.Parse(linea);

        Console.Write("Ingresa el segundo numero: ");
        linea = Console.ReadLine();
        n2 = int.Parse(linea);

        Console.Write("Ingresa el tercer numero: ");
        linea = Console.ReadLine();
        n3 = int.Parse(linea);

        if (n1 < 10 || n2 < 10 || n3 < 10)
        {
            Console.Write("Alguno de los números es menor a diez");
        }
        else
        {
            Console.Write("Ninguno es menor a diez");
        }

        Console.ReadKey();
    }
}