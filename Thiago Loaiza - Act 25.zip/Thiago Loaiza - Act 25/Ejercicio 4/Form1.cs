﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_4
{
    /*
     4. Elaborar una interfaz gráfica que muestre una calculadora (utilizar
        objetos de la clase Button y un objeto de la clase Label donde se
        muestra el valor ingresado), tener en cuenta que solo se debe
        implementar la interfaz y la carga de un valor de hasta 12 dígitos.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}
