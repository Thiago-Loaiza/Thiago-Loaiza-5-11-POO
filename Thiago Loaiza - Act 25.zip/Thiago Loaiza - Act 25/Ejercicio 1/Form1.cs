﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_1
{
    public partial class Form1 : Form
    {
        /*
         1. Elaborar una interfaz gráfica que muestre una calculadora (utilizar
            objetos de la clase Button y un objeto de la clase TextBox donde se
            mostrarían los resultados y se cargarían los datos), tener en cuenta que
            solo se debe implementar la interfaz y no la funcionalidad de una
            calculadora.
         */
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
