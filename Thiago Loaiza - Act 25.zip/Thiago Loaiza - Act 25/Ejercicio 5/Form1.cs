﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string contraseña = textBox1.Text;
            label1.Text = "Su clave es: " + contraseña + " Recuerdela.";
            textBox1.Text = "";
            button1.Enabled = false;
            textBox1.Enabled = false;
            label2.Text = "";
        }
    }
}
