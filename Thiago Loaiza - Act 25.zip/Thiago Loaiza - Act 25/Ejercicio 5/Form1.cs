﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = "Su clave es: " + (textBox1.Text) + " recuerdela.";
            textBox1.Text = "";
            label1.Text = "";
            textBox1.Enabled = false;
            button1.Enabled = false;
        }
    }
}
