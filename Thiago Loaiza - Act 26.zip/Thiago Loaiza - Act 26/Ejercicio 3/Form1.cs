﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_3
{
    /*
     3. Solicitar el ingreso del nombre de una persona y seleccionar de un control
        ComboBox un país. Al presionar un botón mostrar en la barra del título del
        Form el nombre ingresado y el país seleccionado.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Argentina");
            comboBox1.Items.Add("Peru");
            comboBox1.Items.Add("Chile");
            comboBox1.Items.Add("Venezuela");
            comboBox1.Items.Add("Colombia");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Text = "Hola : " + textBox1.Text + " de : " + comboBox1.Text + ", Bienvenido";
        }
    }
}
