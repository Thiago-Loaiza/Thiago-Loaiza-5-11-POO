﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_1
{
    /*
     1. Disponer tres objetos de la clase CheckBox con nombres de navegadores web.
        Cuando se presione un botón mostrar en el título del Form los programas
        seleccionados.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Text = "";
            if (checkBox1.Checked == true)
            {
                Text += "/Chrome";
            }
            if (checkBox2.Checked == true)
            {
                Text += "/Opera";
            }
            if (checkBox3.Checked == true)
            {
                Text += "/Brave";
            }
        }
    }
}
