﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_3
{
    /*
     3. Gestor de Tareas Simplificado (Investigación: ListBox)
    Investigación: Investigar el control ListBox (propiedad Items, métodos Add() y RemoveAt()).
    Explicar brevemente su funcionamiento e incluir un ejemplo resuelto.
    Consigna: Armar una interfaz con un TextBox, un Button "Agregar", un Button "Eliminar" y un ListBox.
    Permitir añadir el texto tipeado a la lista y borrar el elemento que el usuario seleccione.

     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var tarea = textBox1.Text;
            listBox1.Items.Add(tarea);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var item = listBox1.SelectedItem;
            for (int i = 0; i < listBox1.Items.Count; i++) {
                if (listBox1.Items[i] == item) {
                    listBox1.Items.RemoveAt(i);
                }
            }
        }
    }
}
