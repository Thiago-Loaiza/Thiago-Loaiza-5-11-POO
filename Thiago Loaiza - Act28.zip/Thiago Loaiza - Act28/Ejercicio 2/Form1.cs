﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_2
{
    /*
     2. Conversor de Temperatura
        Consigna: Disponer un TextBox para el ingreso numérico y dos RadioButton: "Celsius a Fahrenheit" y "Fahrenheit a Celsius".
        Al presionar un Button, realizar la fórmula correspondiente y mostrar el resultado en un Label.

     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num = int.Parse(textBox1.Text);

            if(radioButton1.Checked == true){
                int valor = (num - 32) * 5 / 9;
                label2.Text = "El valor es: " + valor.ToString() + "°F";
            }
            else
            {
                if(radioButton2.Checked == true){
                    int valor = (num * 9 / 5) + 32;
                    label2.Text = "El valor es: " + valor.ToString() + "°C";
                }
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label3.Text = "Convirtiendo a Celsius a Farenheit";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label3.Text = "Convirtiendo a Farenheit a Celsius";
        }
    }
}
