﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_1
{
    /*
     1. Calculadora de Promedio de Notas
        Consigna: Crear un formulario con tres TextBox para ingresar notas y un Button "Calcular". Convertir los valores con int.Parse()
        o double.Parse() y mostrar en una Label el promedio. Si la nota es mayor o igual a 6,
        cambiar el color del texto de la etiqueta a verde; de lo contrario, a rojo.

     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(textBox1.Text);
            double num2 = double.Parse(textBox2.Text);
            double num3 = double.Parse(textBox3.Text);
 
            double Promedio = (num1 + num2 + num3) / 3;
            if(Promedio > 6)
            {
                label4.ForeColor = Color.Green;
            }
            else
            {
                label4.ForeColor = Color.Red;
            }
            label4.Text = "El promedio de este alumno es: " + Promedio.ToString();
        }
    }
}
