﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_5
{
    /*
     5. Visor Dinámico de Imágenes (Investigación: PictureBox)
        Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y SizeMode.
        Consigna: Cargar en un ComboBox tres opciones. Al cambiar la selección mediante el evento SelectedIndexChanged,
        mostrar la imagen correspondiente dentro del PictureBox.
     */
    public partial class Form1 : Form
    {
        private string imagen1 = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5aQYEhjSHxTri-P8gPukawHxWsquFRhZfuRbPx-6DMw&s=10";
        private string imagen2 = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSudO27CTOAg987bAfXEwH5Db1ZcucVX_Kt5DqoMEoJ9Q&s=10";
        private string imagen3 = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpfeiclknAq9FEwcLYkHn3noEf1n45R3M9IJaXoMR5sA&s=10";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.ImageLocation = imagen1;
            comboBox1.Items.Add("Perro1");
            comboBox1.Items.Add("Perro2");
            comboBox1.Items.Add("Perro3");
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            { 
                pictureBox1.ImageLocation = imagen1;
            }
            if (comboBox1.SelectedIndex == 1)
            {
                pictureBox1.ImageLocation = imagen2;
            }
            if (comboBox1.SelectedIndex == 2)
            {
                pictureBox1.ImageLocation = imagen3;
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
