﻿using System;

public class HelloWorld
{
    public static void Main(string[] args)
    {
        /*
        4.Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.
        */

        int n1, n2 , n3, mayor;
        string linea;

        Console.WriteLine("Ingresa tres numero distintos para obtener el mayor");
        Console.WriteLine("Numero 1 : ");
        linea = Console.ReadLine();
        n1 = int.Parse(linea);


        Console.WriteLine("Numero 2 : ");
        linea = Console.ReadLine();
        n2 = int.Parse(linea);

        if(n1 == n2)
        {
            Console.WriteLine("Condicion rota");
        }
        else
        {
            if (n1 > n2)
            {
                mayor = n1;
            }
            else { mayor = n2; }
            Console.WriteLine("Numero 3 : ");
            linea = Console.ReadLine();
            n3 = int.Parse(linea);
            if (n3 > mayor) {
                mayor = n3; 
            }
            if (n3 == n1 || n3 == n2)
            { 
                Console.WriteLine("Condicion rota");
            }
            else
            {
                Console.WriteLine("El mayor de los tres es: " + mayor);
            }
        }


        Console.ReadKey();
    }
}