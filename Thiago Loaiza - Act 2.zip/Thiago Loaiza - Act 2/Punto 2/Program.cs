﻿using System;

public class HelloWorld
{
    public static void Main(string[] args)
    {
        //2. Se ingresan seis notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje
        //"Promocionado"

        int n1, n2 ,n3 ,n4 ,n5 ,n6;
        float Promedio;
        string linea;

        Console.Write("Ingresa la primera nota");
        linea = Console.ReadLine();
        n1 = int.Parse(linea);

        Console.Write("Ingresa la segunda nota");
        linea = Console.ReadLine();
        n2 = int.Parse(linea);

        Console.Write("Ingresa la tercer nota");
        linea = Console.ReadLine();
        n3 = int.Parse(linea);

        Console.Write("Ingresa la cuarta nota");
        linea = Console.ReadLine();
        n4 = int.Parse(linea);

        Console.Write("Ingresa la quinta nota");
        linea = Console.ReadLine();
        n5 = int.Parse(linea);

        Console.Write("Ingresa la sexta nota");
        linea = Console.ReadLine();
        n6 = int.Parse(linea);

        Promedio = (n1 + n2 + n3 + n4 + n5 + n6) / 6;
        if (Promedio >= 7)
        {
            Console.WriteLine("Alumno Promocionada");
            Console.WriteLine(Promedio);
        }
        else
        {
            Console.WriteLine("Alumno no Promocionado");
        }
        Console.ReadKey();
    }
}