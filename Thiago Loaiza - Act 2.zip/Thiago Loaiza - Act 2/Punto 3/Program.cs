﻿using System;

public class HelloWorld
{
    public static void Main(string[] args)
    {
        //Se ingresa por teclado un número positivo de uno o dos dígitos (1..99) mostrar un mensaje indicando si el número tiene uno o dos dígitos.
        //(Tener en cuenta que condición debe cumplirse para tener dos dígitos, un número entero)

        int n1;
        string linea;

        Console.Write("Ingresa el numero positivo de 1 o 2 digitos");
        linea = Console.ReadLine();
        n1 = int.Parse(linea);
        if(n1 <= 99 && n1 > 0)
        {
            n1 = int.Parse(linea);
            if (n1 > 9)
            {
                Console.WriteLine("El numero tiene 2 digitos");
            }
            else
            {
                Console.WriteLine("El numero tiene 1 digito");
            }
        }
        else
        {
            Console.WriteLine("Ingreso Erroneo");
            Console.WriteLine("El numero tiene que ser positivo de 1 o 2 digitos");
        }
        Console.ReadKey();
    }
}