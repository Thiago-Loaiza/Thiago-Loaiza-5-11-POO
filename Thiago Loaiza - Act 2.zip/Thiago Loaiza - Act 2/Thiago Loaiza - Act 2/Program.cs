﻿using System;

public class HelloWorld
{
    public static void Main(string[] args)
    {
        //1. Realizar un programa que lea por teclado dos números, si el primero es mayor al segundo informar su suma y diferencia,
        //en caso contrario informar el producto y la división del primero respecto al segundo.

        int num1, num2, suma, producto, division;
        string linea;

        Console.Write("Ingresa el primero numero");
        linea = Console.ReadLine();
        num1 = int.Parse(linea);

        Console.Write("Ingresa el primero numero");
        linea = Console.ReadLine();
        num2 = int.Parse(linea);

        suma = num1 + num2;
        producto = num1 * num2;
        division = num1 % num2;

        if (num1 > num2) {
            Console.WriteLine("La suma es : " + suma);
        }
        else
        {
            Console.WriteLine("El producto : " + producto);
            Console.WriteLine("La division es : " + division);
        }
        Console.ReadKey();
    }
}