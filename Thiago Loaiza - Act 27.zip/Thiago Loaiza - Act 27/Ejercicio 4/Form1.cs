﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_4
{
    /*
     Problema:
        Se quiere crear un formulario de opinión para un producto.
        Requisitos:
        ● Un Label debe indicar: &quot;Escribe tu opinión&quot;.
        ● Incluir un TextBox grande (multilínea) donde el usuario escriba su comentario.
        ● Dos RadioButton deben permitir seleccionar sí recomiendan el producto: &quot;Sí&quot; o &quot;No&quot;.
        ● Al hacer clic en el botón &quot;Enviar&quot;, se debe mostrar un Label con el mensaje: &quot;Opinión
        recibida: [texto] – Recomendación: [Sí/No]&quot;.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string opinion = (string)this.textBox1.Text;
            string seleccion = "";
            if (radioButton1.Checked == true)
            {
                seleccion = radioButton1.Text;
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                    seleccion = radioButton2.Text;
                }
            }
            label3.Text = "Opinion recibida" + opinion + "\n El usuario recomenda este producto? " + "[" + seleccion  + "]";
        }
    }
}
