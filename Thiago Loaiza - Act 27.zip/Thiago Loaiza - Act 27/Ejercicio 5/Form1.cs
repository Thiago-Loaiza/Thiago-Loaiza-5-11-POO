﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_5
{
    /*
     Problema:
        Una aplicación ofrece distintos niveles de suscripción.
        Requisitos:
        ● Usar un ComboBox para elegir el tipo de plan: &quot;Gratis&quot;, &quot;Básico&quot;, &quot;Premium&quot;.
        ● Incluir dos CheckBox para elegir servicios adicionales (por ejemplo: &quot;Soporte
        técnico&quot;, &quot;Acceso anticipado&quot;).
        ● Al presionar el botón &quot;Guardar&quot;, se debe mostrar en un Label un resumen con el
        plan y los servicios elegidos.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Gratis");
            comboBox1.Items.Add("Basico");
            comboBox1.Items.Add("Premium");
            comboBox1.Text = "Eliga el plan";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string plan = comboBox1.SelectedItem as string;
            string seleccion = "";

            if (checkBox1.Checked == true)
            {
                seleccion += checkBox1.Text + " - ";
            }
            if (checkBox2.Checked == true)
            {
                seleccion += checkBox2.Text + " - ";
            }
            label1.Text = "El plan elegido es: " + plan + " | Sus servicios adicionales: " + seleccion;
        }
    }
}
