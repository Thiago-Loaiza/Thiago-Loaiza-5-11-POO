﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_2
{
    /*
     Problema:
        Una aplicación quiere conocer los gustos musicales de los usuarios.
        Requisitos:
        ● Mostrar un ComboBox con 5 géneros musicales distintos.
        ● Incluir tres CheckBox que representen actividades relacionadas (por ejemplo:
        &quot;Escuchar en vivo&quot;, &quot;Escuchar en streaming&quot;, &quot;Comprar discos&quot;).
        ● Al presionar un botón &quot;Mostrar Preferencias&quot;, en un Label se debe mostrar el género
        seleccionado y las actividades marcadas.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Rock");
            comboBox1.Items.Add("Jazz");
            comboBox1.Items.Add("Electronica");
            comboBox1.Items.Add("Clasica");
            comboBox1.Items.Add("Breakcore");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            string seleccion = comboBox1.SelectedItem.ToString();
            string seleccion2 = "";

            if (checkBox1.Checked == true)
            {
                seleccion2 += checkBox1.Text + "-";
            }
            if (checkBox2.Checked == true)
            {
                seleccion2 += checkBox2.Text + "-";
            }
            if (checkBox3.Checked == true)
            {
                seleccion2 += checkBox3.Text + "-";
            }



            label1.Text = "Genero elegido : " + seleccion + " | Realizando las siguientes actividades : " + seleccion2;
        }
    }
}
