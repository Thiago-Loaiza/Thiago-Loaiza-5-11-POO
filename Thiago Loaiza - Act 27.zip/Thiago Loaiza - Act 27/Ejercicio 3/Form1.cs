﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_3
{
    /*
     Problema:
        Una agencia de viajes ofrece distintos tipos de paquetes turísticos.
        Requisitos:
        ● Usar tres RadioButton para seleccionar el destino principal: &quot;Playa&quot;, &quot;Montaña&quot; o
        &quot;Ciudad&quot;.

        ● Agregar un ComboBox para elegir la duración del viaje (ejemplo: &quot;3 días&quot;, &quot;7 días&quot;,
        &quot;15 días&quot;).
        ● Un botón &quot;Confirmar&quot; debe mostrar en un Label la opción seleccionada.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("3 dias");
            comboBox1.Items.Add("7 dias");
            comboBox1.Items.Add("15 dias");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string seleccion = comboBox1.SelectedItem as string;
            string seleccion2 = "";
            if (radioButton1.Checked == true) {
                seleccion2 += radioButton1.Text;
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                    seleccion2 += radioButton2.Text;
                }
                else
                {
                    if (radioButton3.Checked == true)
                    {
                        seleccion2 += radioButton3.Text;
                    }
                }
            }

            label1.Text = "El viaje sera en : " + seleccion2 + " | su duracion sera de : " + seleccion;
        }
    }
}
